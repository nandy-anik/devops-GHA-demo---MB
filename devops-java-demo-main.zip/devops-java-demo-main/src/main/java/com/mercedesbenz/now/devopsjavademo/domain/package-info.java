/**
 * JPA domain objects.
 */
package com.mercedesbenz.now.devopsjavademo.domain;
