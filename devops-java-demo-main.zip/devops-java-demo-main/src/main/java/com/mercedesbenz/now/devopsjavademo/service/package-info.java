/**
 * Service layer beans.
 */
package com.mercedesbenz.now.devopsjavademo.service;
