/**
 * Spring Security configuration.
 */
package com.mercedesbenz.now.devopsjavademo.security;
