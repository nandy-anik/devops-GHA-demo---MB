/**
 * Spring Data JPA repositories.
 */
package com.mercedesbenz.now.devopsjavademo.repository;
