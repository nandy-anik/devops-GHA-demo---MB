/**
 * Spring MVC REST controllers.
 */
package com.mercedesbenz.now.devopsjavademo.web.rest;
