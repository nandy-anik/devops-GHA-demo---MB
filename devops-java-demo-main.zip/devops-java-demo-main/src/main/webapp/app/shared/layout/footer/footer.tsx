import './footer.scss';

import React from 'react';

import { Col, Row } from 'reactstrap';

const Footer = () => (
  <div className="footer page-content">
    <Row>
      <Col md="12">
        <p>Created with plenty of fun and even more ❤️ and 🎆 in Bangalore & Stuttgart</p>
      </Col>
    </Row>
  </div>
);

export default Footer;
